// 更多图腾 (More Totems) - Minecraft Bedrock Add-on
// 需要 @minecraft/server 2.6.0+（entityHurt 前置事件已在此版本转为正式版）
import { world, system, EquipmentSlot, EntityDamageCause } from "@minecraft/server";
import { ActionFormData, FormCancelationReason } from "@minecraft/server-ui";

// ───────────── 配置 ─────────────
const CONFIG = {
  substituteRange: 48, // 替死图腾：寻找替死鬼的最大距离
  sparePets: true, // 替死图腾：是否放过已驯服的宠物
  allowKillPlayers: false, // 替死图腾：是否允许选中其他玩家
};

// ───────────── 语言 / Language ─────────────
const CREDIT = {
  zh: "§6[更多图腾] §f此包由 Diandian 制作，如有篡改必究",
  en: "§6[More Totems] §fThis pack was made by Diandian. Tampering will be pursued.",
};
const lang = (player) => (safe(() => player.getDynamicProperty("mt:lang")) === "en" ? "en" : "zh");
const L = (player, zh, en) => (lang(player) === "en" ? en : zh);

// ───────────── 工具函数 ─────────────
const safe = (fn) => {
  try {
    return fn();
  } catch (e) {
    return undefined;
  }
};

const SLOTS = [EquipmentSlot.Mainhand, EquipmentSlot.Offhand];

function heldItems(player) {
  const eq = player.getComponent("equippable");
  const out = [];
  if (!eq) return out;
  for (const slot of SLOTS) {
    const item = safe(() => eq.getEquipment(slot));
    if (item) out.push({ slot, item });
  }
  return out;
}

function particle(dim, id, loc) {
  safe(() => dim.spawnParticle(id, loc));
}

function effect(entity, id, seconds, amp = 0) {
  safe(() => entity.addEffect(id, Math.floor(seconds * 20), { amplifier: amp, showParticles: true }));
}

const EXCLUDED_TYPES = [
  "minecraft:player",
  "minecraft:armor_stand",
  "minecraft:item",
  "minecraft:xp_orb",
  "minecraft:npc",
  "minecraft:lightning_bolt",
];

function livingNear(player, range, opts = {}) {
  const list = player.dimension.getEntities({
    location: player.location,
    maxDistance: range,
    excludeTypes: opts.includePlayers ? EXCLUDED_TYPES.filter((t) => t !== "minecraft:player") : EXCLUDED_TYPES,
  });
  const result = [];
  for (const e of list) {
    if (e.id === player.id) continue;
    const hp = safe(() => e.getComponent("health"));
    if (!hp || hp.currentValue <= 0) continue;
    const dx = e.location.x - player.location.x;
    const dy = e.location.y - player.location.y;
    const dz = e.location.z - player.location.z;
    result.push({ entity: e, dist: dx * dx + dy * dy + dz * dz, dx, dz });
  }
  result.sort((a, b) => a.dist - b.dist);
  return result;
}

function setHealth(player, value) {
  const h = player.getComponent("health");
  if (!h) return;
  h.setCurrentValue(Math.max(1, Math.min(value, h.effectiveMax)));
}

function name(e) {
  return e.nameTag || e.typeId.replace("minecraft:", "");
}

// ───────────── 致命伤害触发型图腾（消耗品） ─────────────
// hp: 触发后的生命值（"max" 为满血）
const LETHAL = {
  "mt:substitute_totem": {
    label: "替死图腾",
    hp: 4,
    run(ctx) {
      const { player } = ctx;
      const cands = livingNear(player, CONFIG.substituteRange, { includePlayers: CONFIG.allowKillPlayers }).filter(
        (c) => !(CONFIG.sparePets && safe(() => c.entity.getComponent("minecraft:is_tamed")))
      );
      effect(player, "regeneration", 20, 1);
      effect(player, "absorption", 10, 1);
      if (cands.length === 0) {
        player.sendMessage(L(player, "§7[替死图腾] 附近没有可以替你死的生物，但你依然活了下来。", "§7[Totem of Substitution] No creature nearby to die for you, but you survived anyway."));
        return;
      }
      const victim = cands[0].entity; // 距离最近的一个（并列时取列表中第一个）
      const loc = victim.location;
      const dim = victim.dimension;
      const label = name(victim);
      safe(() => victim.kill());
      particle(dim, "minecraft:totem_particle", { x: loc.x, y: loc.y + 1, z: loc.z });
      player.sendMessage(L(player, `§5[替死图腾] §f${label} §5替你去死了。`, `§5[Totem of Substitution] §f${label} §5died in your place.`));
    },
  },
  "mt:phoenix_totem": {
    label: "凤凰图腾",
    hp: "max",
    run({ player }) {
      effect(player, "fire_resistance", 60);
      effect(player, "strength", 20, 0);
      for (const c of livingNear(player, 6)) safe(() => c.entity.setOnFire(8, true));
      particle(player.dimension, "minecraft:large_explosion", player.location);
    },
  },
  "mt:life_totem": {
    label: "生命图腾",
    hp: "max",
    run({ player }) {
      effect(player, "regeneration", 30, 2);
      effect(player, "absorption", 30, 3);
    },
  },
  "mt:recall_totem": {
    label: "回城图腾",
    hp: 10,
    run({ player }) {
      const sp = safe(() => player.getSpawnPoint());
      const dim = sp ? sp.dimension : world.getDimension("overworld");
      const dest = sp ? { x: sp.x + 0.5, y: sp.y, z: sp.z + 0.5 } : world.getDefaultSpawnLocation();
      particle(player.dimension, "minecraft:totem_particle", player.location);
      safe(() => player.teleport(dest, { dimension: dim }));
      effect(player, "resistance", 10, 2);
      player.sendMessage(L(player, "§b[回城图腾] 你被传送回了重生点。", "§b[Totem of Recall] You were teleported back to your spawn point."));
    },
  },
  "mt:ender_totem": {
    label: "末影图腾",
    hp: 10,
    run({ player }) {
      for (const c of livingNear(player, 8)) effect(c.entity, "blindness", 6);
      effect(player, "slow_falling", 15);
      if (player.dimension.id === "minecraft:overworld") {
        for (let i = 0; i < 8; i++) {
          const ang = Math.random() * Math.PI * 2;
          const r = 16 + Math.random() * 16;
          const x = player.location.x + Math.cos(ang) * r;
          const z = player.location.z + Math.sin(ang) * r;
          const top = safe(() => player.dimension.getTopmostBlock({ x, z }));
          if (top && top.typeId !== "minecraft:water" && top.typeId !== "minecraft:lava") {
            particle(player.dimension, "minecraft:totem_particle", player.location);
            safe(() => player.teleport({ x, y: top.location.y + 1, z }));
            break;
          }
        }
      }
      player.sendMessage(L(player, "§d[末影图腾] 你闪现到了远处。", "§d[Totem of Ender] You blinked far away."));
    },
  },
  "mt:thunder_totem": {
    label: "雷霆图腾",
    hp: 8,
    run({ player }) {
      effect(player, "fire_resistance", 30);
      effect(player, "resistance", 15, 1);
      for (const c of livingNear(player, 10).slice(0, 6)) {
        safe(() => player.dimension.spawnEntity("minecraft:lightning_bolt", c.entity.location));
      }
    },
  },
  "mt:frost_totem": {
    label: "冰霜图腾",
    hp: 10,
    run({ player }) {
      effect(player, "resistance", 20, 1);
      for (const c of livingNear(player, 8)) {
        effect(c.entity, "slowness", 12, 3);
        effect(c.entity, "weakness", 12, 1);
      }
      particle(player.dimension, "minecraft:totem_particle", player.location);
    },
  },
  "mt:revenge_totem": {
    label: "复仇图腾",
    hp: 8,
    run({ player, attacker }) {
      effect(player, "strength", 30, 1);
      let target = attacker && attacker.id !== player.id && safe(() => attacker.isValid) ? attacker : undefined;
      if (!target) {
        const near = livingNear(player, 12);
        if (near.length) target = near[0].entity;
      }
      if (target) {
        safe(() => target.applyDamage(30));
        player.sendMessage(L(player, `§c[复仇图腾] 你对 §f${name(target)} §c施以了报复。`, `§c[Totem of Vengeance] You took revenge on §f${name(target)}§c.`));
      }
    },
  },
  "mt:guardian_totem": {
    label: "守护图腾",
    hp: 10,
    run({ player }) {
      effect(player, "resistance", 15, 3);
      effect(player, "absorption", 20, 4);
      for (const c of livingNear(player, 6)) {
        const len = Math.hypot(c.dx, c.dz) || 1;
        safe(() => c.entity.applyImpulse({ x: (c.dx / len) * 1.2, y: 0.6, z: (c.dz / len) * 1.2 }));
      }
    },
  },
  "mt:triple_totem": {
    label: "三命图腾",
    hp: 6,
    uses: 3, // 通过耐久实现：可使用 3 次
    run({ player }) {
      effect(player, "regeneration", 10, 1);
      effect(player, "resistance", 5, 1);
    },
  },
};

const VANILLA_TOTEM = "minecraft:totem_of_undying";
const activating = new Set();

// 先找主手/副手，再找整个背包（含快捷栏）
function findTotem(player) {
  const eq = player.getComponent("equippable");
  for (const slot of SLOTS) {
    const item = safe(() => eq.getEquipment(slot));
    if (item && LETHAL[item.typeId]) return { kind: "slot", slot, item };
  }
  const inv = safe(() => player.getComponent("inventory").container);
  if (inv) {
    for (let i = 0; i < inv.size; i++) {
      const item = inv.getItem(i);
      if (item && LETHAL[item.typeId]) return { kind: "inv", index: i, item };
    }
  }
  return undefined;
}

world.beforeEvents.entityHurt.subscribe((ev) => {
  const player = ev.hurtEntity;
  if (player.typeId !== "minecraft:player") return;

  const cause = ev.damageSource.cause;
  if (cause === EntityDamageCause.void || cause === EntityDamageCause.selfDestruct) return; // 与原版一致：虚空和 /kill 无法被挡

  const health = player.getComponent("health");
  if (!health || ev.damage < health.currentValue) return; // 不是致命伤害

  if (heldItems(player).some((h) => h.item.typeId === VANILLA_TOTEM)) return; // 手上有原版图腾，交给原版处理
  if (activating.has(player.id)) {
    ev.cancel = true; // 处理中，同一刻的其他致命伤害一并挡下
    return;
  }
  const found = findTotem(player);
  if (!found) return;

  ev.cancel = true;
  activating.add(player.id);
  const attacker = ev.damageSource.damagingEntity;
  system.run(() => {
    try {
      rescue(player, found, attacker);
    } catch (e) {
      console.warn("[更多图腾] 触发失败: " + e);
    } finally {
      activating.delete(player.id);
    }
  });
});

// 自定义的图腾激发动画：在你面前弹出该图腾自己的贴图，向上飘起并淡出
function popAnimation(player, typeId) {
  const dim = player.dimension;
  const head = player.getHeadLocation();
  const dir = player.getViewDirection();
  particle(dim, "mt:pop_" + typeId.slice(3), {
    x: head.x + dir.x * 1.8,
    y: head.y + dir.y * 1.8 - 0.1,
    z: head.z + dir.z * 1.8,
  });
  particle(dim, "minecraft:totem_particle", { x: player.location.x, y: player.location.y + 1, z: player.location.z });
  safe(() => player.playSound("random.totem"));
}

function rescue(player, found, attacker) {
  if (!safe(() => player.isValid)) return;
  const def = LETHAL[found.item.typeId];
  const eq = player.getComponent("equippable");
  const inv = player.getComponent("inventory").container;
  const cur = found.kind === "slot" ? eq.getEquipment(found.slot) : inv.getItem(found.index);
  if (!cur || cur.typeId !== found.item.typeId) return;

  // 消耗图腾；三命图腾耐久 -1，还有剩余则留下
  let remaining;
  if (def.uses) {
    const dur = cur.getComponent("durability");
    if (dur && dur.damage + 1 < dur.maxDurability) {
      dur.damage += 1;
      remaining = cur;
    }
  }
  if (found.kind === "slot") eq.setEquipment(found.slot, remaining);
  else inv.setItem(found.index, remaining);

  // 与原版一致：清除所有效果、灭火、回血
  for (const e of player.getEffects()) safe(() => player.removeEffect(e.typeId));
  safe(() => player.extinguishFire());
  setHealth(player, def.hp === "max" ? 9999 : def.hp);

  popAnimation(player, found.item.typeId);
  safe(() => player.onScreenDisplay.setActionBar(L(player, `§6${def.label} 已触发`, `§6${NAMES[found.item.typeId][1]} activated`)));
  def.run({ player, attacker });
}

// ───────────── 持有生效型图腾（放在主手或副手） ─────────────
// every: 刷新间隔（tick）；effects: [效果ID, 秒数, 等级]
const PASSIVE = {
  "mt:swift_totem": { effects: [["speed", 3, 1], ["jump_boost", 3, 0]] },
  "mt:deepsea_totem": { effects: [["water_breathing", 3, 0], ["dolphins_grace", 3, 0]] },
  "mt:night_totem": { effects: [["night_vision", 13, 0]] },
  "mt:berserk_totem": { effects: [["strength", 3, 1], ["haste", 3, 1]] },
  "mt:feather_totem": { effects: [["slow_falling", 3, 0], ["jump_boost", 3, 1]] },
  "mt:flame_totem": { effects: [["fire_resistance", 3, 0]] },
  "mt:satiety_totem": { every: 100, effects: [["saturation", 1, 0]] },
  "mt:healing_totem": { effects: [["regeneration", 3, 0]] },
  "mt:magnet_totem": {
    every: 10,
    run(player) {
      const items = player.dimension.getEntities({
        type: "minecraft:item",
        location: player.location,
        maxDistance: 7,
      });
      for (const it of items) {
        safe(() => it.teleport({ x: player.location.x, y: player.location.y + 0.3, z: player.location.z }));
      }
    },
  },
};

// ───────────── 名称与物品说明（按玩家所选语言） ─────────────
const NAMES = {
  "mt:substitute_totem": [
    "替死图腾",
    "Totem of Substitution"
  ],
  "mt:phoenix_totem": [
    "凤凰图腾",
    "Totem of the Phoenix"
  ],
  "mt:life_totem": [
    "生命图腾",
    "Totem of Life"
  ],
  "mt:recall_totem": [
    "回城图腾",
    "Totem of Recall"
  ],
  "mt:ender_totem": [
    "末影图腾",
    "Totem of Ender"
  ],
  "mt:thunder_totem": [
    "雷霆图腾",
    "Totem of Thunder"
  ],
  "mt:frost_totem": [
    "冰霜图腾",
    "Totem of Frost"
  ],
  "mt:revenge_totem": [
    "复仇图腾",
    "Totem of Vengeance"
  ],
  "mt:guardian_totem": [
    "守护图腾",
    "Totem of the Guardian"
  ],
  "mt:triple_totem": [
    "三命图腾",
    "Totem of Three Lives"
  ],
  "mt:swift_totem": [
    "疾风图腾",
    "Totem of Swiftness"
  ],
  "mt:deepsea_totem": [
    "深海图腾",
    "Totem of the Deep"
  ],
  "mt:night_totem": [
    "夜视图腾",
    "Totem of Night Vision"
  ],
  "mt:berserk_totem": [
    "狂战图腾",
    "Totem of the Berserker"
  ],
  "mt:feather_totem": [
    "飞羽图腾",
    "Totem of Feathers"
  ],
  "mt:flame_totem": [
    "烈焰图腾",
    "Totem of Flames"
  ],
  "mt:satiety_totem": [
    "饱食图腾",
    "Totem of Satiety"
  ],
  "mt:magnet_totem": [
    "磁吸图腾",
    "Totem of Magnetism"
  ],
  "mt:healing_totem": [
    "治愈图腾",
    "Totem of Healing"
  ]
};
const DESC = {
  "mt:substitute_totem": [
    "挡下致命伤害，离你最近的一个生物替你去死",
    "Blocks lethal damage; the nearest creature dies in your place"
  ],
  "mt:phoenix_totem": [
    "满血，防火，点燃周围的生物",
    "Full health, fire resistance, ignites nearby creatures"
  ],
  "mt:life_totem": [
    "满血，再生 III，伤害吸收 IV",
    "Full health, Regeneration III, Absorption IV"
  ],
  "mt:recall_totem": [
    "传送回重生点",
    "Teleports you back to your spawn point"
  ],
  "mt:ender_totem": [
    "随机闪现到远处，周围生物失明",
    "Teleports you far away and blinds nearby creatures"
  ],
  "mt:thunder_totem": [
    "对周围生物降下闪电",
    "Strikes nearby creatures with lightning"
  ],
  "mt:frost_totem": [
    "周围生物缓慢并虚弱",
    "Slows and weakens nearby creatures"
  ],
  "mt:revenge_totem": [
    "对攻击者造成 30 点伤害，你获得力量",
    "Deals 30 damage to your attacker, grants Strength"
  ],
  "mt:guardian_totem": [
    "高额抗性与吸收，击飞周围生物",
    "Heavy resistance and absorption, knocks back nearby creatures"
  ],
  "mt:triple_totem": [
    "可抵挡 3 次致命伤害",
    "Blocks lethal damage up to 3 times"
  ],
  "mt:swift_totem": [
    "速度 II + 跳跃提升",
    "Speed II + Jump Boost"
  ],
  "mt:deepsea_totem": [
    "水下呼吸 + 海豚的恩惠",
    "Water Breathing + Dolphin's Grace"
  ],
  "mt:night_totem": [
    "夜视",
    "Night Vision"
  ],
  "mt:berserk_totem": [
    "力量 II + 急迫 II",
    "Strength II + Haste II"
  ],
  "mt:feather_totem": [
    "缓降 + 跳跃提升 II",
    "Slow Falling + Jump Boost II"
  ],
  "mt:flame_totem": [
    "防火",
    "Fire Resistance"
  ],
  "mt:satiety_totem": [
    "缓慢补充饥饿值",
    "Slowly restores hunger"
  ],
  "mt:magnet_totem": [
    "吸取 7 格内的掉落物",
    "Pulls in items within 7 blocks"
  ],
  "mt:healing_totem": [
    "再生 I",
    "Regeneration I"
  ]
};

function tagItems(player) {
  const en = lang(player) === "en";
  const fix = (item) => {
    if (!item || !DESC[item.typeId]) return false;
    const how = LETHAL[item.typeId]
      ? en ? "§eKeep in your inventory: triggers automatically on lethal damage" : "§e放在背包里，受到致命伤害时自动触发"
      : en ? "§eHold in main hand or offhand to take effect" : "§e拿在主手或副手时生效";
    const lore = [how, "§7" + DESC[item.typeId][en ? 1 : 0]];
    // 物品名称由游戏的语言文件决定（创造栏和背包里一致），这里只清理旧版本写入过的改名
    let changed = false;
    if (item.nameTag && NAMES[item.typeId].includes(item.nameTag)) {
      try {
        item.nameTag = undefined;
      } catch (e) {
        item.nameTag = "";
      }
      changed = true;
    }
    const cur = item.getLore();
    if (cur.length === 2 && cur[0] === lore[0] && cur[1] === lore[1]) return changed;
    item.setLore(lore);
    return true;
  };
  const inv = safe(() => player.getComponent("inventory").container);
  if (inv) {
    for (let i = 0; i < inv.size; i++) {
      const it = inv.getItem(i);
      if (fix(it)) inv.setItem(i, it);
    }
  }
  const eq = player.getComponent("equippable");
  const off = safe(() => eq.getEquipment(EquipmentSlot.Offhand));
  if (fix(off)) safe(() => eq.setEquipment(EquipmentSlot.Offhand, off));
}

// ───────────── 进入世界：选择语言 + 署名 ─────────────
async function askLanguage(player) {
  let closed = 0;
  for (let tries = 0; tries < 60; tries++) {
    if (!safe(() => player.isValid)) return;
    const res = await new ActionFormData()
      .title("Language / 语言")
      .body("请选择语言（物品名称跟随游戏本身的语言设置）\nPlease choose your language (item names follow the game's own language setting)")
      .button("中文")
      .button("English")
      .show(player);
    if (!res.canceled) {
      player.setDynamicProperty("mt:lang", res.selection === 1 ? "en" : "zh");
      safe(() => tagItems(player));
      return;
    }
    if (res.cancelationReason === FormCancelationReason.UserClosed && ++closed >= 3) break; // 多次关闭则默认中文
    await new Promise((resolve) => system.runTimeout(resolve, 40)); // 还在加载或开着聊天栏时，稍后重试
  }
  if (safe(() => player.isValid) && !player.getDynamicProperty("mt:lang")) player.setDynamicProperty("mt:lang", "zh");
}

async function greet(player) {
  if (!safe(() => player.isValid)) return;
  if (!player.getDynamicProperty("mt:lang")) await askLanguage(player);
  if (!safe(() => player.isValid)) return;
  player.sendMessage(CREDIT[lang(player)]);
}

world.afterEvents.playerSpawn.subscribe(({ player, initialSpawn }) => {
  if (initialSpawn) system.runTimeout(() => greet(player), 60);
});

// 随时修改语言：在聊天栏输入 /scriptevent mt:language
system.afterEvents.scriptEventReceive.subscribe((ev) => {
  if (ev.id === "mt:language" && ev.sourceEntity && ev.sourceEntity.typeId === "minecraft:player") {
    const pl = ev.sourceEntity;
    pl.setDynamicProperty("mt:lang", undefined);
    askLanguage(pl);
  }
});

let tickCount = 0;
system.runInterval(() => {
  tickCount += 10;
  for (const player of world.getAllPlayers()) {
    if (tickCount % 40 === 0) safe(() => tagItems(player));
    const applied = new Set();
    for (const { item } of heldItems(player)) {
      const def = PASSIVE[item.typeId];
      if (!def || applied.has(item.typeId)) continue;
      applied.add(item.typeId);
      if (tickCount % (def.every ?? 20) !== 0) continue;
      if (def.effects) {
        for (const [id, sec, amp] of def.effects) {
          safe(() => player.addEffect(id, sec * 20, { amplifier: amp, showParticles: false }));
        }
      }
      if (def.run) def.run(player);
    }
  }
}, 10);
